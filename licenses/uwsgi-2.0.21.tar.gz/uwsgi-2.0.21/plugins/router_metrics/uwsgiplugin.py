NAME='router_metrics'

CFLAGS = []
LDFLAGS = []
LIBS = []
GCC_LIST = ['plugin']
