# API Reference

::: ansi2html.Ansi2HTMLConverter
