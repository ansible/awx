This is an Angular/SVG demo that is made for manipulating the candidate
Resin.io logo. It uses the techniques discussed in this [blog post](http://alexandros.resin.io/angular-d3-svg/).

