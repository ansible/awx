For users, docs are now available at http://chardet.github.io.

For devs, you can edit the docs in the `gh-pages` branch on GitHub.
