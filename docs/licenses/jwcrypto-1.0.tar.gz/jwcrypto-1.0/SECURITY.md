# Security Policy

## Supported Versions

| Version | Supported          |
| ------- | ------------------ |
| 0.8 +   | :white_check_mark: |
| < 0.8   | :x:                |

## Reporting a Vulnerability

Please contact simo@redhat.com if you have found a security vulnerability

Expect a response within 2 business days (not on week ends or holidays).

If the vulnerbaility is confirmed and accepted you will be given instruction on any embargo or disclosure timeline via email.
