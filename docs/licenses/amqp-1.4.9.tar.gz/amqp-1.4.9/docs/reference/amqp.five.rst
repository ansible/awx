=====================================================
 amqp.five
=====================================================

.. contents::
    :local:
.. currentmodule:: amqp.five

.. automodule:: amqp.five
    :members:
    :undoc-members:
