================================
 celery.app.registry
================================

.. contents::
    :local:
.. currentmodule:: celery.app.registry

.. automodule:: celery.app.registry
    :members:
    :undoc-members:
