# A test file for HTML reporting by coverage.

import other

if 1 < 2:
    h = 3
else:
    h = 4
