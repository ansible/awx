# My egg file!

walrus = "Eggman"
says = "coo-coo cachoo"
