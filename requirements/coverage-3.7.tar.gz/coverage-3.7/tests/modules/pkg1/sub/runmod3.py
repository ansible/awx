# Used in the tests for run_python_module
import sys
print("runmod3: passed %s" % sys.argv[1])
