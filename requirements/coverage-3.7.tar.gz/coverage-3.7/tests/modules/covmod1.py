# covmod1.py: Simplest module for testing.
i = 1
i += 1
