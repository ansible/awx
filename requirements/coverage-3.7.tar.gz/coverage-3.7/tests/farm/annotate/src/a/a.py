def a(x):
    if x == 1:
        print("x is 1")
    else:
        print("x is not 1")
