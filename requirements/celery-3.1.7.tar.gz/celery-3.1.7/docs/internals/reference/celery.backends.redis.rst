==========================================
 celery.backends.redis
==========================================

.. contents::
    :local:
.. currentmodule:: celery.backends.redis

.. automodule:: celery.backends.redis
    :members:
    :undoc-members:
