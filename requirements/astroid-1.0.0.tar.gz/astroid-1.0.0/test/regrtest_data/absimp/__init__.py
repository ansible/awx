"""a package with absolute import activated
"""

from __future__ import absolute_import

