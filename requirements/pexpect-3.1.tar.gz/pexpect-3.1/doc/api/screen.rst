screen - manage a virtual 'screen'
==================================

.. automodule:: pexpect.screen

.. autoclass:: screen
   :members:

   .. automethod:: __init__
   .. automethod:: __str__