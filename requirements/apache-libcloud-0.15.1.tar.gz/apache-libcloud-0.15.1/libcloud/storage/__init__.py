"""
Module for working with Storage
"""
