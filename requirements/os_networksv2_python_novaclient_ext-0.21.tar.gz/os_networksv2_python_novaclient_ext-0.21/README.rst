=================================
os_networksv2_python_novaclient_ext
=================================

Adds network extension support to python-novaclient.

This extension is autodiscovered once installed. To use::

    pip install os_networksv2_python_novaclient_ext
    nova networks
