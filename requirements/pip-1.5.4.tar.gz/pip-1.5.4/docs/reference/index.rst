===============
Reference Guide
===============

.. toctree::
   :maxdepth: 2

   pip
   pip_install
   pip_uninstall
   pip_freeze
   pip_list
   pip_show
   pip_search
   pip_wheel


