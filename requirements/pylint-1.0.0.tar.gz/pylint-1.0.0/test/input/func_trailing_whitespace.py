"""Regression test for trailing-whitespace (C0303)."""

__revision__ = 0

print 'some trailing whitespace'   
print 'trailing whitespace does not count towards the line length limit'                   
