"""test mixed tabs and spaces"""

__revision__ = 1

def spaces_func():
    """yo"""
    print "yo"

def tab_func():
	"""yo"""
	print "yo"
