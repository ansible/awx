"""
Blank URLConf just to keep runtests.py happy.
"""
from rest_framework.compat import patterns

urlpatterns = patterns('',
)
