function toggle() {
    "use strict";
    var unused, x = true;
    if (x && y) {
        x = false;
    }
}
