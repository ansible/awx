version = (1, 1, 8)
version_string = '.'.join(map(str, version))
