===============================================
 Database Backend - djcelery.backends.database
===============================================

.. contents::
    :local:
.. currentmodule:: djcelery.backends.database

.. automodule:: djcelery.backends.database
    :members:
    :undoc-members:
