# -*- coding: utf-8 -*-
from django.test import TestCase


class SanityCheckTest(TestCase):
    def test_is_ok(self):
        pass
