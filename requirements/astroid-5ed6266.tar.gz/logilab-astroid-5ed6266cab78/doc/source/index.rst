.. Astroid documentation master file, created by
   sphinx-quickstart on Wed Jun 26 15:00:40 2013.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

.. Please see the documentation for the Sphinx Python domain :
   http://sphinx-doc.org/domains.html#the-python-domain
   and the autodoc extension
   http://sphinx-doc.org/ext/autodoc.html


Welcome to Astroid's documentation!
===================================

Contents:

.. toctree::
   :maxdepth: 2

   inference

   extending


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

