version = (1, 1, 7)
version_string = '.'.join(map(str, version))
