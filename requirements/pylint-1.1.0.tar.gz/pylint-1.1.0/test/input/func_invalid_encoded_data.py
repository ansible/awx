# coding: utf-8
"""Test data file with encoding errors."""

__revision__ = 0

STR = 'Су�ествительное'
