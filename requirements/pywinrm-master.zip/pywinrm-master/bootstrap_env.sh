#!/bin/bash
python setup.py bootstrap_env
read -p 'Press [Enter] key to continue...'
