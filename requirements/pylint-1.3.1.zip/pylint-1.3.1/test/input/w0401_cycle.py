"""w0401 dependency
"""

__revision__ = 0

import input.func_w0401

if __revision__:
    print input
