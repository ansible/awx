"""The first thing."""
__revision__ = None
THING1 = "I am thing1"
