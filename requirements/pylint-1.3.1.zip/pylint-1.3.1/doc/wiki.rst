======================
 Pylint messages Wiki
======================

http://pylint-messages.wikidot.com/

