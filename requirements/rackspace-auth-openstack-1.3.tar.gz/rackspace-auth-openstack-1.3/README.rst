Rackspace Auth Plugin for OpenStack Clients
===========================================

.. image:: https://badge.fury.io/py/rackspace-auth-openstack.png
   :target: http://badge.fury.io/py/rackspace-auth-openstack

.. image:: https://travis-ci.org/rackerlabs/rackspace-auth-openstack.png?branch=master
   :target: https://travis-ci.org/rackerlabs/rackspace-auth-openstack

This is a plugin for OpenStack Clients which provides client support for
Rackspace authentication extensions to OpenStack.
