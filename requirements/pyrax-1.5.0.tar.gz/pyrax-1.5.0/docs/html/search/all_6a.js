var searchData=
[
  ['junk',['junk',['../namespacejunk.html',1,'']]],
  ['junk_2epy',['junk.py',['../junk_8py.html',1,'']]]
];
