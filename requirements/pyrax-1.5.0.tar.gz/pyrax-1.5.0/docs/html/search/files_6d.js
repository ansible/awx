var searchData=
[
  ['manager_2epy',['manager.py',['../manager_8py.html',1,'']]]
];
