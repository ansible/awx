var searchData=
[
  ['httpnotimplemented',['HTTPNotImplemented',['../classpyrax_1_1exceptions_1_1HTTPNotImplemented.html',1,'pyrax::exceptions']]]
];
