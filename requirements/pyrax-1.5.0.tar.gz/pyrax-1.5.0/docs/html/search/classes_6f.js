var searchData=
[
  ['overlimit',['OverLimit',['../classpyrax_1_1exceptions_1_1OverLimit.html',1,'pyrax::exceptions']]]
];
