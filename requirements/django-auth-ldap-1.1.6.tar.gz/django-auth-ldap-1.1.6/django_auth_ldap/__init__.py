version = (1, 1, 6)
version_string = '1.1.6'
