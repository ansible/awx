Rackspace Auth Plugin for OpenStack Clients
===========================================

This is a plugin for OpenStack Clients which provides client support for
Rackspace authentication extensions to OpenStack.
